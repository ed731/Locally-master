package com.example.danny.locally;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.content.Intent;
import android.widget.EditText;
import android.widget.Toast;

public class SignUpActivity extends AppCompatActivity
{

    private Button okButton;
    private EditText nameInputText;
    private EditText emailInputText;
    private EditText passwordInputText;
    private EditText confirmPasswordInputText;

    // Called when the activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Get the reference to the Ok Button
        okButton = (Button) findViewById(R.id.okButton);

        // Get the reference to the Name EditText
        nameInputText = (EditText) findViewById(R.id.nameInputText);
        // Get the reference to the Email EditText
        emailInputText = (EditText) findViewById(R.id.emailInputText);
        // Get the reference to the Password EditText
        passwordInputText = (EditText) findViewById(R.id.passwordInputText);
        // Get the reference to the Confirm Password EditText
        confirmPasswordInputText = (EditText) findViewById(R.id.confirmPasswordInputText);
    }

    // Method is when user clicks on the Ok Button
    public void okClicked(View view)
    {

        // Get the reference to the Name EditText
        nameInputText = (EditText) findViewById(R.id.nameInputText);
        // Get the reference to the Email EditText
        emailInputText = (EditText) findViewById(R.id.emailInputText);
        // Get the reference to the Password EditText
        passwordInputText = (EditText) findViewById(R.id.passwordInputText);
        // Get the reference to the Confirm Password EditText
        confirmPasswordInputText = (EditText) findViewById(R.id.confirmPasswordInputText);

        // name text is empty
        if(nameInputText.getText().toString().equals(""))
        {
            // animate shake
            Animation shake = AnimationUtils.loadAnimation(this, R.anim.shake);
            nameInputText.startAnimation(shake);
        }
        // email text is empty
        if(emailInputText.getText().toString().equals(""))
        {
            // animate shake
            Animation shake = AnimationUtils.loadAnimation(this, R.anim.shake);
            emailInputText.startAnimation(shake);
        }
        // password text is empty
        if(passwordInputText.getText().toString().equals(""))
        {
            // animate shake
            Animation shake = AnimationUtils.loadAnimation(this, R.anim.shake);
            passwordInputText.startAnimation(shake);
        }
        // confirm password text is empty
        if(confirmPasswordInputText.getText().toString().equals(""))
        {
            // animate shake
            Animation shake = AnimationUtils.loadAnimation(this, R.anim.shake);
            confirmPasswordInputText.startAnimation(shake);
        }

        // password and confirm password does not match
        if( !(passwordInputText.getText().toString().equals(confirmPasswordInputText.getText().toString())) )
        {
            // send a message
            Toast.makeText(this, "Password does not match. Please try again.", Toast.LENGTH_LONG).show();
        }

        else if( !nameInputText.getText().toString().isEmpty() && !emailInputText.getText().toString().isEmpty()
                && !passwordInputText.getText().toString().isEmpty() && !confirmPasswordInputText.getText().toString().isEmpty()
                && passwordInputText.getText().toString().equals(confirmPasswordInputText.getText().toString()))

        {
            // Open another Activity (Screen)
            Intent intent = new Intent(this, BusinessLayout.class);
            startActivity(intent);
        }

    }


}
