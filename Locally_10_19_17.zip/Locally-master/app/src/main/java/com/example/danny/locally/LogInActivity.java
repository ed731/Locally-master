package com.example.danny.locally;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;

public class LogInActivity extends AppCompatActivity
{

    private Button logInButton;
    private EditText emailEditText;
    private EditText passwordEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        // Get the reference of the Log In button
        logInButton = (Button) findViewById(R.id.logInButton);
        // Get the reference of the Email Edit Text
        emailEditText = (EditText) findViewById(R.id.emailEditText);
        // Get the reference of the Password Edit Text
        passwordEditText = (EditText) findViewById(R.id.passwordEditText);


    }

    // Function is used when log in button is clicked
    public void logInClicked(View view)
    {
        // Get the reference of the Email Edit Text
        emailEditText = (EditText) findViewById(R.id.emailEditText);
        // Get the reference of the Password Edit Text
        passwordEditText = (EditText) findViewById(R.id.passwordEditText);

        // email text is empty
        if(emailEditText.getText().toString().equals(""))
        {
            // animate a shake
            Animation shake = AnimationUtils.loadAnimation(this, R.anim.shake);
            emailEditText.startAnimation(shake);
        }
        // password text is empty
        if(passwordEditText.getText().toString().equals(""))
        {
            // animate a shake
            Animation shake = AnimationUtils.loadAnimation(this, R.anim.shake);
            passwordEditText.startAnimation(shake);

        }

        //Intent intent = new Intent(this, LogInActivity.class);
        //startActivity(intent);
    }

    // Function is used if New Account Text is clicked
    public void newAccountClicked(View view)
    {
        Intent intent = new Intent(this, SignUpActivity.class);
        startActivity(intent);
    }
}
