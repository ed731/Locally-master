package com.example.danny.locally.Utilities;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.view.MenuItem;

import com.example.danny.locally.Camera.CameraActivity;
import com.example.danny.locally.Map.MapActivity;
import com.example.danny.locally.Message.MessageActivity;
import com.example.danny.locally.Profile.ProfileActivity;
import com.example.danny.locally.R;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

/**
 * Created by Danny on 10/17/17.
 * This class is responsible to call Intents of Map, Camera, Message, Profile.
 * It also customize the animation and shifting mode
 */

public class BottomNavigationViewHelper
{
    private static final String TAG = "BottomNavigationViewHelper";

    // Customize the Bottom Navigation View through animation and shifting mode
    public static void setUpBottomNavigationView(BottomNavigationViewEx bottomNavigationViewEx)
    {
        bottomNavigationViewEx.enableAnimation(true);
        bottomNavigationViewEx.enableItemShiftingMode(true);
        bottomNavigationViewEx.enableShiftingMode(true);
    }

    // Sets up the navigation by calling intents through Map, Camera, Message, Profile
    public static void enableNavigation(final Context context, BottomNavigationViewEx view)
    {
        view.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item)
            {
                switch (item.getItemId())
                {
                    case R.id.ic_map:  // Get the reference from menu folder
                        Intent mapIntent = new Intent(context, MapActivity.class);  // Call Map Activity
                        context.startActivity(mapIntent);
                        break;
                    case R.id.ic_camera:    // Get the reference from menu folder
                        Intent cameraIntent = new Intent(context, CameraActivity.class);    // Call Camera Activity
                        context.startActivity(cameraIntent);
                        break;
                    case R.id.ic_message:   // Get the reference from menu folder
                        Intent messageIntent = new Intent(context, MessageActivity.class);  // Call Message Activity
                        context.startActivity(messageIntent);
                        break;
                    case R.id.ic_profile:   // Get the reference from menu folder
                        Intent profileIntent = new Intent(context, ProfileActivity.class);  // Call Profile Activity
                        context.startActivity(profileIntent);
                        break;
                }
                return false;
            }
        });
    }
}
