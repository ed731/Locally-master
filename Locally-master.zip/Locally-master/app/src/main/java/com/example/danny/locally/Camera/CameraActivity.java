package com.example.danny.locally.Camera;

import android.Manifest;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.danny.locally.R;
import com.example.danny.locally.Utilities.BottomNavigationViewHelper;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Created by Danny on 10/17/17.
 * Class creates the Camera Activity
 */

public class CameraActivity extends AppCompatActivity
{
    // TAG
    private static final String TAG = "CameraActivity";
    private static final int ACTIVITY_NUM = 1;
    private static final int CAMERA_REQUEST = 5;
    private static final int CAMERA_PERMISSION_REQUEST_CODE = 10;
    private BottomNavigationViewHelper bottomNavigationViewHelper;
    private BottomNavigationViewEx bottomNavigationViewEx;

    private ImageView publishImageView;
    private Button publishButton;

    private Uri pictureUri;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: CameraActivity Created");
        setContentView(R.layout.activity_camera);

        // Get the reference to Image View
        publishImageView = (ImageView) findViewById(R.id.publishImageView);
        // Get the reference to Button
        publishButton = (Button) findViewById(R.id.publishButton);

        //setUpBottomNavigationView();

        onTakePhoto();
    }

    public void onTakePhoto()
    {
        if(checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
        {
            invokeCamera();
        }
        else
        {
            // user did not accept on permission to take photo
            String[] permissionRequest = {Manifest.permission.CAMERA};
            requestPermissions(permissionRequest, CAMERA_PERMISSION_REQUEST_CODE);
        }
    }

    /*
        Method checks for the request code if user requested the permission for the camera
    */
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == CAMERA_PERMISSION_REQUEST_CODE)
        {
            if(grantResults[0] == PackageManager.PERMISSION_GRANTED)
            {
                invokeCamera();
            }
            else
            {
                Toast.makeText(this, "Cannot take photo without permission", Toast.LENGTH_LONG).show();
            }
        }
    }

    public void invokeCamera()
    {
        Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Get the path of ANDROID OPERATING SYSTEM by looking in the sd card (External Storage)

        File pictureDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        String pictureName = getUniquePictureName();
        File imageFile = new File(pictureDirectory, pictureName);
        pictureUri = Uri.fromFile(imageFile);
        camera.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, pictureUri);

        startActivityForResult(camera, CAMERA_REQUEST);
    }

    // Get unique picture name based on current time. Why use time?? Because if we take more
    // than 1 pic. Then the pic will overwrite so we want to save the string based on the current time.
    // Time is never constant so we get a unique string.
    private String getUniquePictureName()
    {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
        String timeStamp = sdf.format(new Date());
        return "Locally_" + timeStamp + ".jpg";
    }

    // Method check for the request code if user click on ok after taking a picture
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // Did user choose Ok?
        if(resultCode == RESULT_OK)
        {
            if(requestCode == CAMERA_REQUEST)   // request code can be video, audio, image. In this case, is just IMAGE
            {
                // We are getting back results from the camera
                Bitmap cameraImage = BitmapFactory.decodeFile(pictureUri.getPath());    // After saving file we need to retrieve it from URI
                Matrix matrix = new Matrix();
                matrix.postRotate(90);
                cameraImage = Bitmap.createBitmap(cameraImage,0,0,cameraImage.getWidth(),cameraImage.getHeight(),matrix, true);
                publishImageView.setImageBitmap(cameraImage);

            }

        }
    }

    /*
            Bottom Navigation View setup
            Calls BottomNavigationViewHelper class
         */
    private void setUpBottomNavigationView()
    {
        Log.d(TAG, "setUpBottomNavigationView: Setting up Bottom Navigation View");
        // Get the reference of Bottom Navigation View Ex
        bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        // customize the Bottom Navigation View Helper
        bottomNavigationViewHelper.setUpBottomNavigationView(bottomNavigationViewEx);
        // navigate between different intent through the Bottom Navigation View Helper
        bottomNavigationViewHelper.enableNavigation(CameraActivity.this, bottomNavigationViewEx);


        Menu menu = bottomNavigationViewEx.getMenu();
        MenuItem menuItem = menu.getItem(ACTIVITY_NUM);
        menuItem.setChecked(true);
    }
}
