package com.example.danny.locally.Map;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.example.danny.locally.R;
import com.example.danny.locally.Utilities.BottomNavigationViewHelper;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

/**
 * Created by Danny on 10/14/17.
 */

public class MapActivity extends AppCompatActivity
{
    // TAG
    private static final String TAG = "MapActivity";
    // Bottom Tab Page Number
    private static final int ACTIVITY_NUM = 0;

    /*
        When Activity is created
     */
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: MapActivity Created");
        setContentView(R.layout.activity_menu);
        setUpBottomNavigationView();
    }


    /*
        Bottom Navigation View setup
     */
    private void setUpBottomNavigationView()
    {
        Log.d(TAG, "setUpBottomNavigationView: Setting up Bottom Navigation View");
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        BottomNavigationViewHelper.setUpBottomNavigationView(bottomNavigationViewEx);
        BottomNavigationViewHelper.enableNavigation(MapActivity.this, bottomNavigationViewEx);

        Menu menu = bottomNavigationViewEx.getMenu();
        MenuItem menuItem = menu.getItem(ACTIVITY_NUM);
        menuItem.setChecked(true);

    }
}
