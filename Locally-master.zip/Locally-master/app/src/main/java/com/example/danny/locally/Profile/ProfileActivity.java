package com.example.danny.locally.Profile;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.example.danny.locally.R;
import com.example.danny.locally.Utilities.BottomNavigationViewHelper;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

/**
 * Created by Danny on 10/18/17.
 * Class creates the Profile Activity
 * Profile Activity has a ToolBar
 */

public class ProfileActivity extends AppCompatActivity
{
    private static final String TAG = "ProfileActivity";
    private static final int ACTIVITY_NUM = 3;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate: ProfileActivity Created");
        setContentView(R.layout.activity_profile);     // Set view to activity profile
        setUpToolbar();
        setUpBottomNavigationView();
    }

    /*
        Create and set up the tool bar
     */
    private void setUpToolbar()
    {
        // Get the reference of the toolbar
        Toolbar profileToolBar = (Toolbar) findViewById(R.id.profileToolBar);
        setSupportActionBar(profileToolBar);
        // when toolbar is clicked
        profileToolBar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) 
            {
                Log.d(TAG, "onMenuItemClick: Clicked Menu Item " + item);
                switch (item.getItemId())
                {
                    case R.id.profileMenu:
                        Log.d(TAG, "onMenuItemClick: Navigating to profile menu");
                        break;
                }
                return false;
            }
        });
    }



    /*
        Set up Bottom Navigation View
     */
    private void setUpBottomNavigationView()
    {
        Log.d(TAG, "setUpBottomNavigationView: Setting up Bottom Navigation View");
        // Get the reference of Bottom Navigation View Ex
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        // customize the Bottom Navigation View Helper
        BottomNavigationViewHelper.setUpBottomNavigationView(bottomNavigationViewEx);
        // navigate between different intent through the Bottom Navigation View Helper
        BottomNavigationViewHelper.enableNavigation(ProfileActivity.this, bottomNavigationViewEx);

        Menu menu = bottomNavigationViewEx.getMenu();
        MenuItem menuItem = menu.getItem(ACTIVITY_NUM);
        menuItem.setChecked(true);
    }


    // Create the option menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        getMenuInflater().inflate(R.menu.profile_menu, menu);   // get file from menu resource file
        //return super.onCreateOptionsMenu(menu);
        return true;
    }
}
