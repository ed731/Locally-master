package com.example.danny.locally;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;

public class BusinessLayout extends AppCompatActivity {

    private Button businessButton;
    private Button customerButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        // Get the reference of Business Button
        businessButton = (Button) findViewById(R.id.businessButton);
        // Get the reference of Customer Button
        customerButton = (Button) findViewById(R.id.customerButton);

        setContentView(R.layout.activity_business_layout);
    }

    public void businessButtonClicked(View view)
    {
        Intent intent = new Intent(BusinessLayout.this, MenuActivity.class);
        startActivity(intent);
        BusinessLayout.this.finish();

    }

    public void customerButtonClicked(View view)
    {
        Intent intent = new Intent(BusinessLayout.this, MenuActivity.class);
        startActivity(intent);
        BusinessLayout.this.finish();
    }
}
