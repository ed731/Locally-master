package com.example.danny.locally;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity
{
    // Duration of wait
    private final int SPLASH_DISPLAY_LENGTH = 2000;

    private TextView logoTextView;


    // Called when the activity is created
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        logoTextView = (TextView) findViewById(R.id.logoTextView);
        logoTextView.setVisibility(View.INVISIBLE);
        addFadeInAnimation();


         /* New Handler to start the Log In-Activity
         * and close this Splash-Screen after some seconds.*/
        new Handler().postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                // Create an Intent that will start the LogIn-Activity.
                Intent intent = new Intent(MainActivity.this, LogInActivity.class);
                MainActivity.this.startActivity(intent);
                MainActivity.this.finish();
            }
        }, SPLASH_DISPLAY_LENGTH);




    }


    public void addFadeInAnimation()
    {
        Animation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeIn.setDuration(2000);

        fadeIn.setAnimationListener(new Animation.AnimationListener()
        {
            @Override
            public void onAnimationStart(Animation animation)
            {
                logoTextView.setVisibility(View.VISIBLE);

            }

            @Override
            public void onAnimationEnd(Animation animation) {

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        logoTextView.startAnimation(fadeIn);
    }

}
