package com.example.danny.locally;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import com.example.danny.locally.Camera.CameraFragment;
import com.example.danny.locally.Map.MapFragment;
import com.example.danny.locally.Message.MessageFragment;
import com.example.danny.locally.Profile.ProfileFragment;
import com.example.danny.locally.Utilities.BottomNavigationViewHelper;
import com.ittianyu.bottomnavigationviewex.BottomNavigationViewEx;

/**
 * Created by Danny on 10/13/17.
 * Class creates the menu activity
 */

public class MenuActivity extends AppCompatActivity
{
    // TAG
    private static final String TAG = "MenuActivity";
    // View Pager
    private ViewPager viewPager;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        Log.d(TAG, "onCreate: MenuActivity Created");
        // Get reference of the View Pager
        this.viewPager = (ViewPager) findViewById(R.id.container);
        setUpViewPager(viewPager);
        setUpBottomNavigationView();
    }

    /*
        Adds 4 fragments: Map, Camera, Message, Profile
    */
    private void setUpViewPager(ViewPager viewPager)
    {
        SectionsPagerAdapter adapter = new SectionsPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new MapFragment()); // Add Map Fragment
        adapter.addFragment(new CameraFragment());  // Add Camera Fragment
        adapter.addFragment(new MessageFragment()); // Add Message Fragment
        adapter.addFragment(new ProfileFragment()); // Add Profile Fragment
        viewPager.setAdapter(adapter);
        // Get the reference to Bottom Navigation View Ex
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        bottomNavigationViewEx.setupWithViewPager(viewPager);
    }


    /*
        Bottom Navigation View setup
     */
    private void setUpBottomNavigationView()
    {
        Log.d(TAG, "setUpBottomNavigationView: Setting up Bottom Navigation View");
        BottomNavigationViewEx bottomNavigationViewEx = (BottomNavigationViewEx) findViewById(R.id.bottomNavViewBar);
        BottomNavigationViewHelper.setUpBottomNavigationView(bottomNavigationViewEx);
        BottomNavigationViewHelper.enableNavigation(this, bottomNavigationViewEx);
    }
}
