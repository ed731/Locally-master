package com.example.esthe.locallysplash;

import android.media.Image;
import android.support.v7.app.AppCompatActivity;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;

public class SplashActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        //startActivity(new Intent(SplashActivity.this, HomeActivity.class));

        final ImageView imageView = (ImageView)findViewById(R.id.imageView_0);
        final ImageView imageView1 = (ImageView)findViewById(R.id.imageView_1);
        final ImageView imageView2 = (ImageView)findViewById(R.id.imageView_2);
        final ImageView imageView3 = (ImageView)findViewById(R.id.imageView_3);
        final ImageView imageView4 = (ImageView)findViewById(R.id.imageView_4);
        final ImageView imageView5 = (ImageView)findViewById(R.id.imageView_5);
        final ImageView imageView6 = (ImageView)findViewById(R.id.imageView_6);
        final ImageView imageView7 = (ImageView)findViewById(R.id.imageView_7);
        final ImageView imageView8 = (ImageView)findViewById(R.id.imageView_8);
        final Animation animation_1 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.fade_in_out);
        final Animation animation_2 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.fade_in_out);
        final Animation animation_3 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.fade_in_out);
        final Animation animation_4 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.fade_in_out);
        final Animation animation_5 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.fade_in_out);
        final Animation animation_6 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.fade_in_out);
        final Animation animation_7 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.fade_in_out);
        final Animation animation_8 = AnimationUtils.loadAnimation(getBaseContext(), R.anim.fade_out);


        imageView1.setVisibility(View.INVISIBLE);
        imageView2.setVisibility(View.INVISIBLE);
        imageView3.setVisibility(View.INVISIBLE);
        imageView4.setVisibility(View.INVISIBLE);
        imageView5.setVisibility(View.INVISIBLE);
        imageView6.setVisibility(View.INVISIBLE);
        imageView7.setVisibility(View.INVISIBLE);
        imageView8.setVisibility(View.INVISIBLE);



        //imageView.startAnimation(animation_1);
        imageView1.startAnimation(animation_1);

        animation_1.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView2.startAnimation(animation_2);




            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        animation_2.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView3.startAnimation(animation_3);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        animation_3.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView4.startAnimation(animation_4);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        animation_4.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView5.startAnimation(animation_5);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        animation_5.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView6.startAnimation(animation_6);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        animation_6.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView7.startAnimation(animation_7);


            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        animation_7.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView8.startAnimation(animation_8);
                imageView8.setVisibility(View.VISIBLE);
                imageView.setVisibility(View.VISIBLE);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });

        animation_8.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                imageView.setVisibility(View.VISIBLE);
                imageView1.setVisibility(View.INVISIBLE);
                imageView2.setVisibility(View.INVISIBLE);
                imageView3.setVisibility(View.INVISIBLE);
                imageView4.setVisibility(View.INVISIBLE);
                imageView5.setVisibility(View.INVISIBLE);
                imageView6.setVisibility(View.INVISIBLE);
                imageView7.setVisibility(View.INVISIBLE);
                //imageView8.setVisibility(View.VISIBLE);

                finish();
                Intent i = new Intent(getBaseContext(), HomeActivity.class);
                startActivity(i);

            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });



    }

}
