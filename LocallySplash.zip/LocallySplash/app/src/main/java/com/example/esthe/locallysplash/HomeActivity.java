package com.example.esthe.locallysplash;

/**
 * Created by esthe on 11/1/2017.
 */
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.Activity;
import android.widget.ImageView;
import android.content.Intent;

public class HomeActivity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_activity);


    }
}
