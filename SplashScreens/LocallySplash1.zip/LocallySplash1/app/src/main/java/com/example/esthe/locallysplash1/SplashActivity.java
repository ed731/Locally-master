package com.example.esthe.locallysplash1;

import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.media.Image;
import android.content.Intent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.FrameLayout;
import android.widget.ImageView;

/**
 * Created by esthe on 11/5/2017.
 */

public class SplashActivity extends Activity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_activity);

        FrameLayout frameLayout = (FrameLayout)findViewById(R.id.background1);
        final FrameLayout frameLayout1 = (FrameLayout)findViewById(R.id.background2);
        final ImageView imageView = (ImageView)findViewById(R.id.imageView);
        final Animation animation_1 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.fade_in);
        final Animation animation_2 = AnimationUtils.loadAnimation(getBaseContext(),R.anim.fade_in);

        imageView.setVisibility(View.VISIBLE);
        frameLayout1.setVisibility(View.INVISIBLE);

        frameLayout.startAnimation(animation_1);

        animation_1.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {

            }

            @Override
            public void onAnimationEnd(Animation animation) {
                frameLayout1.setVisibility(View.VISIBLE);
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
                finish();

                //Intent i = new Intent(getBaseContext(), MainActivity.class);
                //startActivity(i);


            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
    }

}
